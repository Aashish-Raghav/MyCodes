#include<stdio.h>
double getDouble() ;
int main() {
    return 0 ;
}
double getDouble() {
    
}