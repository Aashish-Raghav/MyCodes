// print all letters in english alphabet using a pointer.

//????