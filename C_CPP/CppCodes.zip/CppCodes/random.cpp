#include<iostream>
#include<cstdlib>

int main() {
    std::cout << "My guess is : " << rand();
}