/*
#include<iostream>
using namespace std;

int main() {
    std::cout << "hello World!\n";
    std::cout << std::endl;
    std::cout << "guys";
    std::cout << std::endl;
    return 0;
} */
#include<iostream>
using namespace std;

int main() 
{
    int carrots = 25;
    cout << "I have " << carrots << " carrots." << endl;
    carrots--;
    cout <<"Crunch,crunch. Now I have " << carrots << " carrots." << endl;
    return 0;
}