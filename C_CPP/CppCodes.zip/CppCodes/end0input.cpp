#include<iostream>
int main() 
{
    using namespace std;
    int x;
    for (cin >> x;x !=0 ; cin >> x);  //***
    return 0;
}